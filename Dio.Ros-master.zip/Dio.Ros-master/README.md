.travis.yml
## Welcome to GitHub Pages

You can use the [editor on GitHub](https://github.com/oscarg933/Dio.Ros/edit/master/README.md) to maintain and preview the content for your website in Markdown files.

Whenever you commit to this repository, GitHub Pages will run [Jekyll](https://jekyllrb.com/) to rebuild the pages in your site, from the content in your Markdown files.

### Markdown

Markdown is a lightweight and easy-to-use syntax for styling your writing. It includes conventions for

```markdown
Syntax highlighted code block

# Header 1
## Header 2
### Header 3

- Bulleted
- List

1. Numbered
2. List

**Bold** and _Italic_ and `Code` text

[Link](url) and ![Image](src)
```

For more details see [GitHub Flavored Markdown](https://guides.github.com/features/mastering-markdown/).

### Jekyll Themes

Your Pages site will use the layout and styles from the Jekyll theme you have selected in your [repository settings](https://github.com/oscarg933/Dio.Ros/settings). The name of this theme is saved in the Jekyll `_config.yml` configuration file.

### Support or Contact

Having trouble with Pages? Check out our [documentation](https://help.github.com/categories/github-pages-basics/) or [contact support](https://github.com/contact) and we’ll help you sort it out.
Hacker theme
Hacker is a theme for GitHub Pages.

Download as .zip Download as .tar.gz View on GitHub
Text can be bold, italic, strikethrough or keyword.

Link to another page.

There should be whitespace between paragraphs.

There should be whitespace between paragraphs. We recommend including a README, or a file with information about your project.

Header 1

This is a normal paragraph following a header. GitHub is a code hosting platform for version control and collaboration. It lets you and others work together on projects from anywhere.

Header 2

This is a blockquote following a header.

When something is important enough, you do it even if the odds are not in your favor.

Header 3

// Javascript code with syntax highlighting.
var fun = function lang(l) {
  dateformat.i18n = require('./lang/' + l)
  return true;
}
# Ruby code with syntax highlighting
GitHubPages::Dependencies.gems.each do |gem, version|
  s.add_dependency(gem, "= #{version}")
end
Header 4

This is an unordered list following a header.
This is an unordered list following a header.
This is an unordered list following a header.
HEADER 5
This is an ordered list following a header.
This is an ordered list following a header.
This is an ordered list following a header.
HEADER 6
head1	head two	three
ok	good swedish fish	nice
out of stock	good and plenty	nice
ok	good oreos	hmm
ok	good zoute drop	yumm
There’s a horizontal rule below this.

Here is an unordered list:

Item foo
Item bar
Item baz
Item zip
And an ordered list:

Item one
Item two
Item three
Item four
And a nested list:

level 1 item
level 2 item
level 2 item
level 3 item
level 3 item
level 1 item
level 2 item
level 2 item
level 2 item
level 1 item
level 2 item
level 2 item
level 1 item
Small image

Octocat

Large image

Branching

