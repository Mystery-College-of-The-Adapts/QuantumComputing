----------------------------------!ATTENTION!----------------------------------
ATTENTION!ATTENTION!ATTENTION!ATTENTION!ATTENTION!ATTENTION!ATTENTION!ATTENTION
----------------------------------!ATTENTION!----------------------------------


PRECONDITION: none

----------------------------------!ATTENTION!----------------------------------
ATTENTION!ATTENTION!ATTENTION!ATTENTION!ATTENTION!ATTENTION!ATTENTION!ATTENTION
----------------------------------!ATTENTION!----------------------------------

---------------------------------------------------------------------------
				
Binary file:	"sehprimosapp-mac-1.0.1.dmg"
Version:		1.0.1
Type:           SEH primos App
Target:         MAC OS X (64bit)
                (10.8.x, 10.9.x, 10.10.x)				


SOFTWARE NEWS: New SEH primos App 1.0.1
-----------------------------------------------------------------------------

The SEH primos App is a software application developed by SEH Computertechnik
GmbH to simplify the administration of primos devices. The SEH primos App
offers the following functions:

- Device discovery
- Open primos Control Center
- Software upload for devices in BIOS mode

This software is delivered as it is. SEH Computertechnik GmbH will not accept 
any liability for any error or omission.

Update Note:
Administrator privileges are required for installation.

It is recommended to uninstall the previous version of the SEH primos App at first 
and restart the system prior to installing this version. This will ensure a clean 
installation and prevent any leftovers on the system from the previous installation.

If you need further assistance, please contact our support team:
Web:   http://www.seh-technology.com/support
Phone: +49 (0)521 94226-44
Email: support@seh.de


Release Notes:
---------------------------------------------------------------------------

New Software Version:   1.0.1

New Features/Changes/Fixes: Initial Release

1) General:
-----------
-

2) Changes: 
----------- 
- 

3) Fixes:
---------
- 

-------------------------------------------------------------------------------

SEH Computertechnik GmbH
Suedring 11
33647 Bielefeld
Phone:          +49 (0)521 94226-29 
Fax:            +49 (0)521 94226-99 
Support:        +49 (0)521 94226-44 
Email:          info@seh.de 
Web:            www.seh.de 

Free Guarantee Extension:
http://www.seh-technology.com/services/warranty.html  
Support Contacts & Information:
http://www.seh-technology.com/services/support.html  
Sales Contacts & Information:
http://www.seh-technology.com/services/customer-service.html

Visit the SEH Computertechnik GmbH Homepage at http://www.seh.de, the myUTN
Portal at http://myutn.de, or subscribe to the SEH Newsletter via
<mailto:newsletter@seh.de?subject=Newsletter abonnieren> to learn more about
Products, Update information, tips, hints & more... 