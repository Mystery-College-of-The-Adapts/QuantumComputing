#ifndef DTS_ENC_H
#define DTS_ENC_H
int dtsenc_init();
int dtsenc_start();
int dtsenc_pause();
int dtsenc_resume();
int dtsenc_stop();
int dtsenc_release();

#endif

