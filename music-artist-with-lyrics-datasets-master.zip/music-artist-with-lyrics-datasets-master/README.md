# Music Artist with lyrics datasets

This dataset can be used for Natural Language Processing purposes, such as clustering of the words with similar meanings or predicting artist by the song. The dataset can be expanded with some more features for more advanced research like sentiment analysis. The data is not modified, only slightly cleaned, which gives a lot of freedom to devise your own applications.
