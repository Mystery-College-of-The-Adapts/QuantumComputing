package com.matterhornlegal.models;

import java.util.ArrayList;

/**
 * Created by seema.gurtatta on 12/28/2017.
 */

public class DataResponseModel extends BaseModel {
    private ArrayList<DataModel> data;

    public ArrayList<DataModel> getData() {
        return data;
    }
}
