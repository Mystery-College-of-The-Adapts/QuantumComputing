package com.matterhornlegal.customui;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;

/**
 * Created by karan.kalsi on 9/28/2017.
 */

public class AppDemoViewPager extends ViewPager {
    public AppDemoViewPager(Context context) {
        super(context);
    }

    public AppDemoViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }


}
