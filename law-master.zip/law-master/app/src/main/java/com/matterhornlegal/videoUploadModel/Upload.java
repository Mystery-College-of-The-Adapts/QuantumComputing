package com.matterhornlegal.videoUploadModel;

/**
 * Created by gaurav.singh on 6/1/2018.
 */

public class Upload {
    private String upload_link;

    public String getUpload_link() {
        return upload_link;
    }

    public void setUpload_link(String upload_link) {
        this.upload_link = upload_link;
    }
}
