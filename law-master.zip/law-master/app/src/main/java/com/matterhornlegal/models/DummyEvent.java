package com.matterhornlegal.models;

/**
 * Created by karan.kalsi on 9/28/2017.
 */

public class DummyEvent {
}
