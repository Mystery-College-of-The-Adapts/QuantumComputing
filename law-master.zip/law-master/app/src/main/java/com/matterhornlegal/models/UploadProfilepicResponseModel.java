package com.matterhornlegal.models;

/**
 * Created by gaurav.singh on 5/7/2018.
 */

public class UploadProfilepicResponseModel extends BaseModel {
    private String profile_pic;

    public String getProfile_pic() {
        return profile_pic;
    }

    public void setProfile_pic(String profile_pic) {
        this.profile_pic = profile_pic;
    }
}
