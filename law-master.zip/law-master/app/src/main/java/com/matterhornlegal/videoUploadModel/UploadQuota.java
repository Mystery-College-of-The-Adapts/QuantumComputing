package com.matterhornlegal.videoUploadModel;

/**
 * Created by gaurav.singh on 6/1/2018.
 */

public class UploadQuota {
    private Space space;

    public Space getSpace() {
        return space;
    }

    public void setSpace(Space space) {
        this.space = space;
    }
}
