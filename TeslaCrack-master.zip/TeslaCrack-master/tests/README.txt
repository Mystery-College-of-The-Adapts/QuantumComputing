## How to create long dir/files:

mkdir -p '1! dirname_300_chars-made_mul_6_x_this_section(50)/2! dirname_300_chars-made_mul_6_x_this_section(50)/3! long_dir dirname_300_chars-made_mul_6_x_this_section(50)'
cd       '1! dirname_300_chars-made_mul_6_x_this_section(50)/2! dirname_300_chars-made_mul_6_x_this_section(50)/3! long_dir dirname_300_chars-made_mul_6_x_this_section(50)'
mkdir -p '4! dirname_300_chars-made_mul_6_x_this_section(50)/5! dirname_300_chars-made_mul_6_x_this_section(50)/6! dirname_300_chars-made_mul_6_x_this_section(50)'
cd       '4! dirname_300_chars-made_mul_6_x_this_section(50)/5! dirname_300_chars-made_mul_6_x_this_section(50)/6! dirname_300_chars-made_mul_6_x_this_section(50)'
cp ../../../../../../../tesla1.pdf.ccc .

cd ../../../../../..
