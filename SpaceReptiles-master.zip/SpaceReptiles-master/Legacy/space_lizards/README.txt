Hey Matt,

So to run this program, I just put it into the htdocs folder.  So
in my browser, I type in localhost/space_lizards to view all the 
files that I wrote. to actually run the program, the logon.php is
the primary thing to run so you can just type:
localhost/space_lizards/logon.php
this page will take you to home1.php in the home directory.  from
here, you can either go to the story/adventure part of the site,
or go to the contact page.  The logon screen puts you in the 
database, and the contact page puts your message to the Lizard
God into the database in a separate table.  All the pages should
be relatively navigable, meaning you can get around and won't get
stuck on one page (hopefully).
Please email me if something doesn't work, I tested it on two 
computers and it seems to work.  I guess if you can't get the 
mysql to work, then because of the logon screen, you might have
trouble getting around the site.  In this case, I could show you
the project on my laptop if we could meet up.  Just let me know,
Thanks!

Peter Schaldenbrand
pls21@pitt.edu